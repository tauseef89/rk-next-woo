<?php
/**
 * Plugin Name: Rakesh Next.js WooCommerce Auth & Rewards
 * Description: Custom APIs for Next.js customer login, guest order linking, and reward points.
 * Version: 1.0.1
 * Author: Rakesh Retails
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * IMPORTANT:
 * Change this secret to your own long random string before going live.
 * Do not use JWT_AUTH_SECRET_KEY here. This plugin uses its own custom token.
 */
if (!defined('RAKESH_AUTH_SECRET')) {
    error_log('RAKESH_AUTH_SECRET is missing from wp-config.php.');
    wp_die('Authentication configuration is missing.');
}

/**
 * Create reward points table on plugin activation
 */
register_activation_hook(__FILE__, 'rakesh_create_rewards_table');

function rakesh_create_rewards_table() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'rakesh_reward_points';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        order_id BIGINT UNSIGNED DEFAULT NULL,
        points INT NOT NULL,
        type VARCHAR(30) NOT NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'active',
        expiry_date DATETIME DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY order_id (order_id),
        KEY type (type),
        KEY status (status),
        KEY expiry_date (expiry_date)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

/**
 * Register REST API routes
 */
add_action('rest_api_init', function () {

    register_rest_route('rakesh/v1', '/login', [
        'methods'             => 'POST',
        'callback'            => 'rakesh_customer_login',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('rakesh/v1', '/register', [
        'methods'             => 'POST',
        'callback'            => 'rakesh_customer_register',
        'permission_callback' => '__return_true',
    ]);
    
    register_rest_route('rakesh/v1', '/forgot-password', array(
        'methods' => 'POST',
        'callback' => 'rakesh_forgot_password',
        'permission_callback' => '__return_true',
    ));
    
    register_rest_route('rakesh/v1', '/reset-password', array(
        'methods' => 'POST',
        'callback' => 'rakesh_reset_password',
        'permission_callback' => '__return_true',
    ));

    register_rest_route('rakesh/v1', '/me', [
        'methods'             => 'GET',
        'callback'            => 'rakesh_get_current_customer',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('rakesh/v1', '/orders', [
        'methods'             => 'GET',
        'callback'            => 'rakesh_get_customer_orders',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('rakesh/v1', '/points', [
        'methods'             => 'GET',
        'callback'            => 'rakesh_get_customer_points',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('rakesh/v1', '/link-guest-orders', [
        'methods'             => 'POST',
        'callback'            => 'rakesh_link_guest_orders_api',
        'permission_callback' => '__return_true',
    ]);
    
    register_rest_route('rakesh/v1', '/address', [
        'methods'  => 'PUT',
        'callback' => 'rakesh_update_customer_address',
        'permission_callback' => '__return_true',
    ]);
    
    register_rest_route('rakesh/v1', '/details', [
        'methods'  => 'PUT',
        'callback' => 'rakesh_update_customer_details',
        'permission_callback' => '__return_true',
    ]);
    
    register_rest_route('rakesh/v1', '/wishlist', [
        'methods'  => 'GET',
        'callback' => 'rakesh_get_customer_wishlist',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('rakesh/v1', '/wishlist', [
        'methods'  => 'PUT',
        'callback' => 'rakesh_update_customer_wishlist',
        'permission_callback' => '__return_true',
    ]);
});


function rakesh_update_customer_address(WP_REST_Request $request) {
    $token = rakesh_get_token_from_request($request);
    $user_id = rakesh_validate_token($token);

    if (!$user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Unauthorized.'
        ], 401);
    }

    $type = sanitize_text_field($request->get_param('type'));
    $address = $request->get_param('address');

    if (!in_array($type, ['billing', 'shipping'], true)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Invalid address type.'
        ], 400);
    }

    if (!is_array($address)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Address data is required.'
        ], 400);
    }

    $allowed_fields = [
        'first_name',
        'last_name',
        'address_1',
        'address_2',
        'city',
        'state',
        'postcode',
        'country',
        'phone',
    ];

    foreach ($allowed_fields as $field) {
        $value = isset($address[$field]) ? sanitize_text_field($address[$field]) : '';
        update_user_meta($user_id, $type . '_' . $field, $value);
    }

    if ($type === 'billing' && isset($address['phone'])) {
        update_user_meta($user_id, 'billing_phone', sanitize_text_field($address['phone']));
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => ucfirst($type) . ' address updated successfully.',
    ], 200);
}

function rakesh_update_customer_details(WP_REST_Request $request) {
    $token = rakesh_get_token_from_request($request);
    $user_id = rakesh_validate_token($token);

    if (!$user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Unauthorized.'
        ], 401);
    }

    $first_name   = sanitize_text_field($request->get_param('first_name'));
    $last_name    = sanitize_text_field($request->get_param('last_name'));
    $display_name = sanitize_text_field($request->get_param('display_name'));
    $email        = sanitize_email($request->get_param('email'));
    $password     = $request->get_param('password');
    $wishlist     = $request->get_param('wishlist');

    $current_user = get_user_by('id', $user_id);

    if (!$current_user) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'User not found.'
        ], 404);
    }

    if (!$email || !is_email($email)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Valid email address is required.'
        ], 400);
    }

    $existing_user_id = email_exists($email);

    if ($existing_user_id && intval($existing_user_id) !== intval($user_id)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'This email address is already used by another account.'
        ], 409);
    }

    $update_data = [
        'ID'           => $user_id,
        'first_name'   => $first_name,
        'last_name'    => $last_name,
        'display_name' => $display_name ?: trim($first_name . ' ' . $last_name),
        'user_email'   => $email,
    ];

    if (!empty($password)) {
        $update_data['user_pass'] = $password;
    }

    $updated = wp_update_user($update_data);

    if (is_wp_error($updated)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $updated->get_error_message()
        ], 400);
    }

    update_user_meta($user_id, 'billing_first_name', $first_name);
    update_user_meta($user_id, 'billing_last_name', $last_name);
    update_user_meta($user_id, 'billing_email', $email);

    if (is_array($wishlist)) {
        $wishlist = array_map('intval', $wishlist);
        update_user_meta($user_id, 'saved_wishlist', wp_json_encode($wishlist));
    }

    $user = get_user_by('id', $user_id);

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Account details updated successfully.',
        'user' => [
            'id'    => $user->ID,
            'name'  => $user->display_name,
            'email' => $user->user_email,
        ],
    ], 200);
}

function rakesh_get_customer_wishlist(WP_REST_Request $request) {
    $token = rakesh_get_token_from_request($request);
    $user_id = rakesh_validate_token($token);

    if (!$user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Unauthorized.'
        ], 401);
    }

    $wishlist = get_user_meta($user_id, 'saved_wishlist', true);
    $wishlist = json_decode($wishlist, true);

    if (!is_array($wishlist)) {
        $wishlist = [];
    }

    $wishlist = array_values(array_unique(array_map('intval', $wishlist)));

    return new WP_REST_Response([
        'success' => true,
        'wishlist' => $wishlist,
    ], 200);
}

function rakesh_update_customer_wishlist(WP_REST_Request $request) {
    $token = rakesh_get_token_from_request($request);
    $user_id = rakesh_validate_token($token);

    if (!$user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Unauthorized.'
        ], 401);
    }

    $wishlist = $request->get_param('wishlist');

    if (!is_array($wishlist)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Wishlist must be an array.'
        ], 400);
    }

    $wishlist = array_values(array_unique(array_map('intval', $wishlist)));

    update_user_meta($user_id, 'saved_wishlist', wp_json_encode($wishlist));

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Wishlist updated successfully.',
        'wishlist' => $wishlist,
    ], 200);
}

/**
 * Token helpers
 */
function rakesh_generate_token($user_id) {
    $payload = [
        'user_id' => intval($user_id),
        'expiry'  => time() + (7 * 24 * 60 * 60), // 7 days
    ];

    $payload_json = wp_json_encode($payload);
    $payload_base64 = base64_encode($payload_json);
    $signature = hash_hmac('sha256', $payload_base64, RAKESH_AUTH_SECRET);

    return $payload_base64 . '.' . $signature;
}

function rakesh_validate_token($token) {
    if (!$token || strpos($token, '.') === false) {
        return false;
    }

    $parts = explode('.', $token);

    if (count($parts) !== 2) {
        return false;
    }

    [$payload_base64, $signature] = $parts;

    $expected_signature = hash_hmac('sha256', $payload_base64, RAKESH_AUTH_SECRET);

    if (!hash_equals($expected_signature, $signature)) {
        return false;
    }

    $payload = json_decode(base64_decode($payload_base64), true);

    if (!$payload || empty($payload['user_id']) || empty($payload['expiry'])) {
        return false;
    }

    if (time() > intval($payload['expiry'])) {
        return false;
    }

    return intval($payload['user_id']);
}

function rakesh_get_token_from_request($request) {
    $custom_token = $request->get_header('x-rakesh-token');

    if ($custom_token) {
        return sanitize_text_field($custom_token);
    }

    $auth_header = $request->get_header('authorization');

    if ($auth_header && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
        return $matches[1];
    }

    return false;
}

/**
 * Login API
 */
function rakesh_customer_login(WP_REST_Request $request) {
    $email    = sanitize_email($request->get_param('email'));
    $password = $request->get_param('password');

    if (!$email || !$password) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Email and password are required.'
        ], 400);
    }

    $user = wp_authenticate($email, $password);

    if (is_wp_error($user)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Invalid email or password.'
        ], 401);
    }

    // Link old guest orders automatically after login.
    rakesh_link_guest_orders_by_email($user->ID, $user->user_email);

    $token = rakesh_generate_token($user->ID);

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Login successful.',
        'token'   => $token,
        'user'    => [
            'id'    => $user->ID,
            'name'  => $user->display_name,
            'email' => $user->user_email,
        ]
    ], 200);
}

/**
 * Register API
 */
function rakesh_customer_register(WP_REST_Request $request) {
    $name     = sanitize_text_field($request->get_param('name'));
    $email    = sanitize_email($request->get_param('email'));
    $phone    = preg_replace('/\D+/', '', (string) $request->get_param('phone'));
    $password = $request->get_param('password');

    if (!$name || !$email || !$password || !$phone) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Name, email, phone and password are required.'
        ], 400);
    }

    // India mobile validation
    if (strlen($phone) === 12 && substr($phone, 0, 2) === '91') {
        $phone = substr($phone, 2);
    }

    if (strlen($phone) !== 10) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Please enter a valid 10-digit mobile number.'
        ], 400);
    }

    if (!is_email($email)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Please enter a valid email address.'
        ], 400);
    }

    if (email_exists($email)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'An account already exists with this email.'
        ], 409);
    }

    $user_id = wp_create_user($email, $password, $email);

    if (is_wp_error($user_id)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $user_id->get_error_message()
        ], 400);
    }

    $name_parts = preg_split('/\s+/', trim($name), 2);
    $first_name = $name_parts[0] ?? '';
    $last_name = $name_parts[1] ?? '';

    wp_update_user([
        'ID'           => $user_id,
        'display_name' => $name,
        'role'         => 'customer',
    ]);

    update_user_meta($user_id, 'first_name', $first_name);
    update_user_meta($user_id, 'last_name', $last_name);

    update_user_meta($user_id, 'billing_first_name', $first_name);
    update_user_meta($user_id, 'billing_last_name', $last_name);
    update_user_meta($user_id, 'billing_email', $email);
    update_user_meta($user_id, 'billing_phone', $phone);

    rakesh_link_guest_orders_by_email($user_id, $email);

    do_action('rakesh_customer_registered', $user_id, $email, $name);

    $token = rakesh_generate_token($user_id);

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Account created successfully. Your WELCOME1K coupon has been sent to your email.',
        'token'   => $token,
        'coupon'  => [
            'code'   => defined('RAKESH_WELCOME_COUPON_CODE')
                ? RAKESH_WELCOME_COUPON_CODE
                : 'WELCOME1K',
            'amount' => defined('RAKESH_WELCOME_COUPON_AMOUNT')
                ? RAKESH_WELCOME_COUPON_AMOUNT
                : 1000,
        ],
        'user' => [
            'id'    => $user_id,
            'name'  => $name,
            'email' => $email,
            'phone' => $phone,
        ]
    ], 201);
}

function rakesh_forgot_password(WP_REST_Request $request) {
    $email = sanitize_email($request->get_param('email'));

    if (empty($email)) {
        return new WP_REST_Response(array(
            'success' => false,
            'message' => 'Email is required.',
        ), 400);
    }

    $user = get_user_by('email', $email);

    /**
     * Do not reveal whether email exists or not.
     */
    if (!$user) {
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'If an account exists, a reset link has been sent.',
        ), 200);
    }

    $key = get_password_reset_key($user);

    if (is_wp_error($key)) {
        return new WP_REST_Response(array(
            'success' => false,
            'message' => strip_tags($key->get_error_message()),
        ), 400);
    }

    /**
     * Change this to your actual frontend domain.
     * Do not use shop.rakeshretails.in here.
     */
    $frontend_url = 'https://rakeshretails.com';

    $reset_url = add_query_arg(
        array(
            'key' => $key,
            'login' => rawurlencode($user->user_login),
        ),
        trailingslashit($frontend_url) . 'reset-password'
    );

    $subject = 'Reset your password';

    $message = '
        <p>Hello ' . esc_html($user->display_name) . ',</p>
        <p>You requested to reset your password.</p>
        <p>Click the link below to set a new password:</p>
        <p><a href="' . esc_url($reset_url) . '">Reset Password</a></p>
        <p>If you did not request this, please ignore this email.</p>
    ';

    $headers = array('Content-Type: text/html; charset=UTF-8');

    $sent = wp_mail($user->user_email, $subject, $message, $headers);

    if (!$sent) {
        return new WP_REST_Response(array(
            'success' => false,
            'message' => 'Unable to send reset email. Please check SMTP settings.',
        ), 500);
    }

    return new WP_REST_Response(array(
        'success' => true,
        'message' => 'Password reset email sent successfully.',
    ), 200);
}

function rakesh_reset_password(WP_REST_Request $request) {
    $login = sanitize_text_field($request->get_param('login'));
    $key = sanitize_text_field($request->get_param('key'));
    $password = $request->get_param('password');

    if (empty($login) || empty($key) || empty($password)) {
        return new WP_REST_Response(array(
            'success' => false,
            'message' => 'Reset key, login and password are required.',
        ), 400);
    }

    if (strlen($password) < 6) {
        return new WP_REST_Response(array(
            'success' => false,
            'message' => 'Password must be at least 6 characters.',
        ), 400);
    }

    $user = check_password_reset_key($key, $login);

    if (is_wp_error($user)) {
        return new WP_REST_Response(array(
            'success' => false,
            'message' => 'Invalid or expired reset link.',
        ), 400);
    }

    reset_password($user, $password);

    return new WP_REST_Response(array(
        'success' => true,
        'message' => 'Password reset successfully.',
    ), 200);
}

/**
 * Logged-in customer API
 */
function rakesh_get_current_customer(WP_REST_Request $request) {
    $token = rakesh_get_token_from_request($request);
    $user_id = rakesh_validate_token($token);

    if (!$user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Unauthorized.'
        ], 401);
    }

    $user = get_user_by('id', $user_id);

    if (!$user) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'User not found.'
        ], 404);
    }

    return new WP_REST_Response([
    'success' => true,
    'user' => [
        'id'    => $user->ID,
        'name'  => $user->display_name,
        'email' => $user->user_email,
        'phone' => get_user_meta($user->ID, 'billing_phone', true),

        'billing' => [
            'first_name' => get_user_meta($user->ID, 'billing_first_name', true),
            'last_name'  => get_user_meta($user->ID, 'billing_last_name', true),
            'address_1'  => get_user_meta($user->ID, 'billing_address_1', true),
            'address_2'  => get_user_meta($user->ID, 'billing_address_2', true),
            'city'       => get_user_meta($user->ID, 'billing_city', true),
            'state'      => get_user_meta($user->ID, 'billing_state', true),
            'postcode'   => get_user_meta($user->ID, 'billing_postcode', true),
            'country'    => get_user_meta($user->ID, 'billing_country', true) ?: 'IN',
            'phone'      => get_user_meta($user->ID, 'billing_phone', true),
            'email'      => $user->user_email,
        ],

        'shipping' => [
            'first_name' => get_user_meta($user->ID, 'shipping_first_name', true),
            'last_name'  => get_user_meta($user->ID, 'shipping_last_name', true),
            'address_1'  => get_user_meta($user->ID, 'shipping_address_1', true),
            'address_2'  => get_user_meta($user->ID, 'shipping_address_2', true),
            'city'       => get_user_meta($user->ID, 'shipping_city', true),
            'state'      => get_user_meta($user->ID, 'shipping_state', true),
            'postcode'   => get_user_meta($user->ID, 'shipping_postcode', true),
            'country'    => get_user_meta($user->ID, 'shipping_country', true) ?: 'IN',
            'phone'      => get_user_meta($user->ID, 'shipping_phone', true),
        ],

        'wishlist' => json_decode(get_user_meta($user->ID, 'saved_wishlist', true), true) ?: [],
    ]
], 200);
}

/**
 * Manual guest order linking API
 */
function rakesh_link_guest_orders_api(WP_REST_Request $request) {
    $token = rakesh_get_token_from_request($request);
    $user_id = rakesh_validate_token($token);

    if (!$user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Unauthorized.'
        ], 401);
    }

    $user = get_user_by('id', $user_id);

    if (!$user) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'User not found.'
        ], 404);
    }

    $linked_count = rakesh_link_guest_orders_by_email($user_id, $user->user_email);

    return new WP_REST_Response([
        'success'       => true,
        'message'       => 'Guest orders linked successfully.',
        'linked_orders' => $linked_count
    ], 200);
}

/**
 * Link guest orders by billing email.
 * If a linked order is already processing/completed, points are added immediately.
 */
function rakesh_link_guest_orders_by_email($user_id, $email) {
    if (!function_exists('wc_get_orders')) {
        return 0;
    }

    $orders = wc_get_orders([
        'limit'         => -1,
        'billing_email' => $email,
        'customer_id'   => 0,
        'status'        => ['pending', 'processing', 'completed', 'on-hold'],
    ]);

    $count = 0;

    foreach ($orders as $order) {
        $order->set_customer_id($user_id);
        $order->save();

        // Copy billing/shipping address from guest order to customer profile
        rakesh_copy_order_address_to_customer($user_id, $order);

        // Add points if guest order is already paid
        if ($order->has_status(['processing', 'completed'])) {
            rakesh_add_points_on_paid_order($order->get_id());
        }

        $count++;
    }

    return $count;
}

function rakesh_copy_order_address_to_customer($user_id, $order) {
    if (!$user_id || !$order) {
        return;
    }

    // Billing address
    update_user_meta($user_id, 'billing_first_name', $order->get_billing_first_name());
    update_user_meta($user_id, 'billing_last_name', $order->get_billing_last_name());
    update_user_meta($user_id, 'billing_company', $order->get_billing_company());
    update_user_meta($user_id, 'billing_address_1', $order->get_billing_address_1());
    update_user_meta($user_id, 'billing_address_2', $order->get_billing_address_2());
    update_user_meta($user_id, 'billing_city', $order->get_billing_city());
    update_user_meta($user_id, 'billing_state', $order->get_billing_state());
    update_user_meta($user_id, 'billing_postcode', $order->get_billing_postcode());
    update_user_meta($user_id, 'billing_country', $order->get_billing_country() ?: 'IN');
    update_user_meta($user_id, 'billing_phone', $order->get_billing_phone());
    update_user_meta($user_id, 'billing_email', $order->get_billing_email());

    // Shipping address
    update_user_meta($user_id, 'shipping_first_name', $order->get_shipping_first_name() ?: $order->get_billing_first_name());
    update_user_meta($user_id, 'shipping_last_name', $order->get_shipping_last_name() ?: $order->get_billing_last_name());
    update_user_meta($user_id, 'shipping_company', $order->get_shipping_company());
    update_user_meta($user_id, 'shipping_address_1', $order->get_shipping_address_1() ?: $order->get_billing_address_1());
    update_user_meta($user_id, 'shipping_address_2', $order->get_shipping_address_2() ?: $order->get_billing_address_2());
    update_user_meta($user_id, 'shipping_city', $order->get_shipping_city() ?: $order->get_billing_city());
    update_user_meta($user_id, 'shipping_state', $order->get_shipping_state() ?: $order->get_billing_state());
    update_user_meta($user_id, 'shipping_postcode', $order->get_shipping_postcode() ?: $order->get_billing_postcode());
    update_user_meta($user_id, 'shipping_country', $order->get_shipping_country() ?: $order->get_billing_country() ?: 'IN');
}

/**
 * Add points when payment is successful.
 * Pine Labs payment success will usually move order to processing.
 * Duplicate points are prevented inside the function.
 */
add_action('woocommerce_order_status_processing', 'rakesh_add_points_on_paid_order');
add_action('woocommerce_order_status_completed', 'rakesh_add_points_on_paid_order');

function rakesh_add_points_on_paid_order($order_id) {
    global $wpdb;

    if (!function_exists('wc_get_order')) {
        return;
    }

    $order = wc_get_order($order_id);

    if (!$order) {
        return;
    }

    $user_id = $order->get_customer_id();

    if (!$user_id) {
        return;
    }

    $table_name = $wpdb->prefix . 'rakesh_reward_points';

    // Prevent duplicate points for same order.
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE order_id = %d AND type = %s",
        $order_id,
        'earned'
    ));

    if ($existing > 0) {
        return;
    }

    $order_total = floatval($order->get_total());

    // Reward rule: 1 point for every ₹100 spent.
    $points = floor($order_total / 100);

    if ($points <= 0) {
        return;
    }

    // Points expire after 3 months.
    $expiry_date = date('Y-m-d H:i:s', strtotime('+3 months', current_time('timestamp')));

    $wpdb->insert($table_name, [
        'user_id'     => $user_id,
        'order_id'    => $order_id,
        'points'      => $points,
        'type'        => 'earned',
        'status'      => 'active',
        'expiry_date' => $expiry_date,
        'created_at'  => current_time('mysql'),
    ], [
        '%d',
        '%d',
        '%d',
        '%s',
        '%s',
        '%s',
        '%s',
    ]);

    $order->add_order_note($points . ' reward points earned.');
}

/**
 * Reward points API for Next.js dashboard
 */
/**
 * Reward points API for Next.js dashboard
 *
 * Logic:
 * - Earned points come from custom rewards table.
 * - Redeemed points are deducted from active WooCommerce orders using order meta:
 *   reward_points_redeemed
 *
 * Active redemption statuses:
 * pending, processing, completed, on-hold
 *
 * If payment fails/cancelled, those statuses are excluded and points return automatically.
 */
function rakesh_get_customer_points(WP_REST_Request $request) {
    global $wpdb;

    $token = rakesh_get_token_from_request($request);
    $user_id = rakesh_validate_token($token);

    if (!$user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Unauthorized.'
        ], 401);
    }

    $table_name = $wpdb->prefix . 'rakesh_reward_points';

    /**
     * Expire old active earned points.
     */
    $wpdb->query($wpdb->prepare(
        "UPDATE $table_name
         SET status = %s
         WHERE user_id = %d
         AND status = %s
         AND expiry_date IS NOT NULL
         AND expiry_date < NOW()",
        'expired',
        $user_id,
        'active'
    ));

    /**
     * Total earned points from custom table.
     */
    $earned = intval($wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(points), 0)
         FROM $table_name
         WHERE user_id = %d
         AND type = %s
         AND status = %s",
        $user_id,
        'earned',
        'active'
    )));

    /**
     * Redeemed points should come from WooCommerce order meta.
     * Your Next.js checkout saves this meta:
     * reward_points_redeemed
     */
    $redeemed = 0;
    $redemption_history = [];

    if (function_exists('wc_get_orders')) {
        $redemption_orders = wc_get_orders([
            'customer_id' => $user_id,
            'limit'       => -1,
            'orderby'     => 'date',
            'order'       => 'DESC',
            'status'      => ['pending', 'processing', 'completed', 'on-hold'],
        ]);

        foreach ($redemption_orders as $order) {
            $points_redeemed = intval($order->get_meta('reward_points_redeemed'));

            if ($points_redeemed > 0) {
                $redeemed += $points_redeemed;

                $redemption_history[] = [
                    'order_id'    => $order->get_id(),
                    'points'      => $points_redeemed,
                    'type'        => 'redeemed',
                    'status'      => $order->get_status(),
                    'expiry_date' => null,
                    'created_at'  => $order->get_date_created()
                        ? $order->get_date_created()->date('Y-m-d H:i:s')
                        : '',
                ];
            }
        }
    }

    /**
     * Points expiring soon.
     */
    $expiring_soon = intval($wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(points), 0)
         FROM $table_name
         WHERE user_id = %d
         AND type = %s
         AND status = %s
         AND expiry_date IS NOT NULL
         AND expiry_date > NOW()
         AND expiry_date <= DATE_ADD(NOW(), INTERVAL 15 DAY)",
        $user_id,
        'earned',
        'active'
    )));

    $available = max(0, $earned - $redeemed);

    /**
     * Earned history from custom table.
     */
    $earned_history = $wpdb->get_results($wpdb->prepare(
        "SELECT order_id, points, type, status, expiry_date, created_at
         FROM $table_name
         WHERE user_id = %d
         ORDER BY created_at DESC
         LIMIT 20",
        $user_id
    ), ARRAY_A);

    /**
     * Merge earned + redeemed history.
     */
    $history = array_merge($redemption_history, $earned_history);

    usort($history, function ($a, $b) {
        return strtotime($b['created_at']) - strtotime($a['created_at']);
    });

    $history = array_slice($history, 0, 20);

    return new WP_REST_Response([
        'success' => true,
        'points' => [
            'earned'        => $earned,
            'redeemed'      => $redeemed,
            'available'     => $available,
            'expiring_soon' => $expiring_soon,
            'point_value'   => 1,
            'earning_rule'  => 'You earn 1 point for every ₹100 spent.',
            'expiry_rule'   => 'Points expire after 3 months.',
            'history'       => $history,
        ]
    ], 200);
}

/**
 * Customer orders API
 */
function rakesh_get_customer_orders(WP_REST_Request $request) {
    $token = rakesh_get_token_from_request($request);
    $user_id = rakesh_validate_token($token);

    if (!$user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Unauthorized.'
        ], 401);
    }

    if (!function_exists('wc_get_orders')) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'WooCommerce is not active.'
        ], 500);
    }

    $per_page = intval($request->get_param('per_page'));

    if (!$per_page || $per_page < 1) {
        $per_page = 5;
    }

    if ($per_page > 20) {
        $per_page = 20;
    }

    $orders = wc_get_orders([
        'customer_id' => $user_id,
        'limit'       => $per_page,
        'orderby'     => 'date',
        'order'       => 'DESC',
    ]);

    $data = [];

    foreach ($orders as $order) {
        $items = [];

        foreach ($order->get_items() as $item) {
            $items[] = [
                'name'     => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'total'    => $item->get_total(),
            ];
        }

        $data[] = [
            'id'       => $order->get_id(),
            'number'   => $order->get_order_number(),
            'status'   => $order->get_status(),
            'total'    => $order->get_total(),
            'currency' => $order->get_currency(),
            'date'     => $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : '',
            'items'    => $items,
        ];
    }

    return new WP_REST_Response([
        'success' => true,
        'orders'  => $data
    ], 200);
}
