<?php
/**
 * Plugin Name: Rakesh Welcome Coupon Email
 * Description: Creates WELCOME1K coupon and sends welcome coupon email after customer registration.
 * Version: 1.0.0
 * Author: Rakesh Retails
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Basic Settings
 */
if (!defined('RAKESH_WELCOME_COUPON_CODE')) {
    define('RAKESH_WELCOME_COUPON_CODE', 'WELCOME1K');
}

if (!defined('RAKESH_WELCOME_COUPON_AMOUNT')) {
    define('RAKESH_WELCOME_COUPON_AMOUNT', 1000);
}

if (!defined('RAKESH_FRONTEND_SHOP_URL')) {
    define('RAKESH_FRONTEND_SHOP_URL', 'https://rakeshretails.com/shop');
}

if (!defined('RAKESH_SUPPORT_PHONE')) {
    define('RAKESH_SUPPORT_PHONE', '8130047218');
}

/**
 * Create coupon when plugin is activated.
 */
register_activation_hook(__FILE__, 'rakesh_welcome_coupon_activate_plugin');

function rakesh_welcome_coupon_activate_plugin() {
    rakesh_welcome_coupon_ensure_coupon_exists();
}

/**
 * Create WELCOME1K coupon if it does not already exist.
 */
function rakesh_welcome_coupon_ensure_coupon_exists() {
    if (!class_exists('WC_Coupon') || !function_exists('wc_get_coupon_id_by_code')) {
        return false;
    }

    $coupon_code = RAKESH_WELCOME_COUPON_CODE;

    $existing_coupon_id = wc_get_coupon_id_by_code($coupon_code);

    if ($existing_coupon_id) {
        return $existing_coupon_id;
    }

    $coupon = new WC_Coupon();

    $coupon->set_code($coupon_code);
    $coupon->set_description('Welcome coupon for new customers - ₹1,000 discount.');
    $coupon->set_discount_type('fixed_cart');
    $coupon->set_amount(RAKESH_WELCOME_COUPON_AMOUNT);

    /**
     * Coupon settings
     */
    $coupon->set_individual_use(true);
    $coupon->set_usage_limit_per_user(1);
    $coupon->set_free_shipping(false);

    /**
     * Optional minimum order amount.
     * Uncomment if you want minimum order value.
     */
    // $coupon->set_minimum_amount(5000);

    $coupon_id = $coupon->save();

    return $coupon_id;
}

/**
 * Hook 1:
 * Normal WordPress/WooCommerce registration.
 */
add_action('user_register', 'rakesh_welcome_coupon_on_user_register', 20, 1);

function rakesh_welcome_coupon_on_user_register($user_id) {
    $user_id = intval($user_id);

    if (!$user_id) {
        return;
    }

    /**
     * Schedule email after a few seconds because your custom API sets role/meta
     * after wp_create_user().
     */
    if (!wp_next_scheduled('rakesh_welcome_coupon_send_scheduled_email', [$user_id])) {
        wp_schedule_single_event(time() + 10, 'rakesh_welcome_coupon_send_scheduled_email', [$user_id]);
    }
}

/**
 * Hook 2:
 * When user role becomes customer.
 */
add_action('set_user_role', 'rakesh_welcome_coupon_on_set_user_role', 20, 3);

function rakesh_welcome_coupon_on_set_user_role($user_id, $role, $old_roles) {
    if ($role === 'customer') {
        rakesh_welcome_coupon_send_to_user($user_id);
    }
}

/**
 * Hook 3:
 * Custom hook from your Rakesh registration API.
 *
 * Add this in your register function:
 * do_action('rakesh_customer_registered', $user_id, $email, $name);
 */
add_action('rakesh_customer_registered', 'rakesh_welcome_coupon_on_custom_registration', 10, 3);

function rakesh_welcome_coupon_on_custom_registration($user_id, $email = '', $name = '') {
    rakesh_welcome_coupon_send_to_user($user_id);
}

/**
 * Scheduled fallback email.
 */
add_action('rakesh_welcome_coupon_send_scheduled_email', 'rakesh_welcome_coupon_send_to_user', 10, 1);

/**
 * Main function to send coupon email.
 */
function rakesh_welcome_coupon_send_to_user($user_id) {
    $user_id = intval($user_id);

    if (!$user_id) {
        return false;
    }

    $user = get_user_by('id', $user_id);

    if (!$user || empty($user->user_email)) {
        return false;
    }

    /**
     * Send only to customers.
     */
    $user_roles = is_array($user->roles) ? $user->roles : [];

    if (!in_array('customer', $user_roles, true)) {
        return false;
    }

    /**
     * Prevent duplicate email.
     */
    $already_sent = get_user_meta($user_id, '_rakesh_welcome_coupon_email_sent', true);

    if ($already_sent === 'yes') {
        return false;
    }

    /**
     * Create coupon if missing.
     */
    $coupon_id = rakesh_welcome_coupon_ensure_coupon_exists();

    if (!$coupon_id) {
        return false;
    }

    $email = $user->user_email;
    $name  = $user->display_name ?: $user->user_login;

    $sent = rakesh_welcome_coupon_send_email($email, $name);

    if ($sent) {
        update_user_meta($user_id, '_rakesh_welcome_coupon_email_sent', 'yes');
        update_user_meta($user_id, '_rakesh_welcome_coupon_code', RAKESH_WELCOME_COUPON_CODE);
        update_user_meta($user_id, '_rakesh_welcome_coupon_sent_at', current_time('mysql'));
    }

    return $sent;
}

/**
 * Email template.
 */
function rakesh_welcome_coupon_send_email($email, $name = '') {
    if (!$email || !is_email($email)) {
        return false;
    }

    $coupon_code   = RAKESH_WELCOME_COUPON_CODE;
    $coupon_amount = RAKESH_WELCOME_COUPON_AMOUNT;
    $shop_url      = RAKESH_FRONTEND_SHOP_URL;
    $support_phone = RAKESH_SUPPORT_PHONE;

    $customer_name = $name ? esc_html($name) : 'Customer';

    $subject = 'Welcome to Rakesh Retails - Your ₹1,000 Coupon Inside';

    $message = '
    <div style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;">
      <div style="max-width:640px;margin:0 auto;padding:24px;">
        <div style="background:#ffffff;border-radius:20px;overflow:hidden;border:1px solid #eeeeee;">
          
          <div style="background:#020617;padding:34px 28px;text-align:center;color:#ffffff;">
            <h1 style="margin:0;font-size:28px;line-height:1.3;font-weight:800;">
              Welcome to Rakesh Retails
            </h1>
            <p style="margin:10px 0 0;color:#cbd5e1;font-size:14px;">
              Your account has been created successfully.
            </p>
          </div>

          <div style="padding:34px 28px;text-align:center;">
            <p style="font-size:16px;color:#111827;margin:0 0 14px;font-weight:700;">
              Hi ' . $customer_name . ',
            </p>

            <p style="font-size:15px;color:#4b5563;line-height:1.7;margin:0 0 24px;">
              Thank you for registering with Rakesh Retails. As a welcome gift,
              use the coupon below and get ₹' . number_format($coupon_amount) . ' discount on your purchase.
            </p>

            <div style="background:#fef3c7;border:2px dashed #eab308;border-radius:18px;padding:24px;margin:26px 0;">
              <p style="margin:0 0 10px;font-size:12px;color:#92400e;font-weight:800;text-transform:uppercase;letter-spacing:1px;">
                Your Coupon Code
              </p>

              <div style="font-size:34px;font-weight:900;letter-spacing:4px;color:#000000;">
                ' . esc_html($coupon_code) . '
              </div>

              <p style="margin:12px 0 0;font-size:13px;color:#78350f;font-weight:600;">
                Flat ₹' . number_format($coupon_amount) . ' discount
              </p>
            </div>

            <a href="' . esc_url($shop_url) . '"
              style="display:inline-block;background:#000000;color:#ffffff;text-decoration:none;padding:15px 30px;border-radius:14px;font-size:14px;font-weight:800;">
              Start Shopping
            </a>

            <p style="font-size:12px;color:#6b7280;line-height:1.6;margin:26px 0 0;">
              The coupon will be applicable on a minimum purchase value of INR 10,000.
            </p>
            <p style="font-size:12px;color:#6b7280;line-height:1.6;margin:26px 0 0;">
              Coupon can be used once per customer. Apply this code during checkout.
            </p>
          </div>

          <div style="background:#f9fafb;padding:18px;text-align:center;border-top:1px solid #eeeeee;">
            <p style="margin:0;font-size:12px;color:#6b7280;">
              24X7 Support: ' . esc_html($support_phone) . '
            </p>
          </div>

        </div>
      </div>
    </div>';

    $headers = [
        'Content-Type: text/html; charset=UTF-8',
    ];

    return wp_mail($email, $subject, $message, $headers);
}

/**
 * Coupon validation.
 *
 * WELCOME1K rules:
 * - User must be logged in.
 * - Coupon is only for first paid order.
 */
add_filter('woocommerce_coupon_is_valid', 'rakesh_welcome_coupon_validate_coupon', 10, 2);

function rakesh_welcome_coupon_validate_coupon($valid, $coupon) {
    if (!$coupon) {
        return $valid;
    }

    if (strtoupper($coupon->get_code()) !== strtoupper(RAKESH_WELCOME_COUPON_CODE)) {
        return $valid;
    }

    if (!is_user_logged_in()) {
        throw new Exception('Please login to use WELCOME1K coupon.');
    }

    $user_id = get_current_user_id();

    if (!$user_id || !function_exists('wc_get_orders')) {
        return $valid;
    }

    $paid_orders = wc_get_orders([
        'customer_id' => $user_id,
        'limit'       => 1,
        'status'      => ['processing', 'completed'],
        'return'      => 'ids',
    ]);

    if (!empty($paid_orders)) {
        throw new Exception('WELCOME1K coupon is valid only for your first order.');
    }

    return $valid;
}

/**
 * Optional helper shortcode for testing:
 * [rakesh_send_welcome_coupon_test]
 *
 * Use only when logged in as admin.
 */
add_shortcode('rakesh_send_welcome_coupon_test', 'rakesh_welcome_coupon_test_shortcode');

function rakesh_welcome_coupon_test_shortcode() {
    if (!current_user_can('manage_options')) {
        return '';
    }

    if (!is_user_logged_in()) {
        return 'Please login first.';
    }

    $user_id = get_current_user_id();

    delete_user_meta($user_id, '_rakesh_welcome_coupon_email_sent');

    $sent = rakesh_welcome_coupon_send_to_user($user_id);

    return $sent ? 'Welcome coupon email sent.' : 'Email not sent. Please check user role, WooCommerce, or SMTP.';
}